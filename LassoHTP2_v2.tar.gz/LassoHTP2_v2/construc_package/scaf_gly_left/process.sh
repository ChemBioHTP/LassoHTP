for i in {7,8,9}; do for j in {3..50}; do
cat>test.pml<<EOF
load r${i}_l${j}.pdb
create mirror, r${i}_l${j}
align mirror, r${i}_l${j}
alter_state 1, mirror, (x, y, z) = (x, -y, z)
sort
save r${i}_l${j}.pdb, mirror
EOF
pymol -c test.pml
 done ; done
