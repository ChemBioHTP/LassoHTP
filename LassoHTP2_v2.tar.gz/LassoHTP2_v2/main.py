import sys
import os
sys.path.append('/your/path/to/LassoHTP2_v2/construc_package')  # Change path
from Class_LassoConstructor import SequenceProcessor

def main():
    # Define input parameters directly
    sequence = "WGDGSIDYFNRPMHIHDWQIMDSGYYG"  
    ring_len = 7  
    loop_len = 7 
    workdir = "./test1"  
    direction = "right"  # Direction of lasso peptide folding: 'right' (right-handed) or 'left' (left-handed), default is 'right'.

    main_script_dir = os.path.dirname(os.path.abspath(__file__))
    processor = SequenceProcessor(sequence=sequence, ring_len=ring_len, loop_len=loop_len, fold_direction=direction, wk_dir=workdir, main_script_dir=main_script_dir)
    processor.process_sequence()

if __name__ == "__main__":
    main()



